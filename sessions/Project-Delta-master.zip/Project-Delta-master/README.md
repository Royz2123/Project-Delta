# Delta
A project that takes a static Arlo camera, and finds the difference in the video feed.  
